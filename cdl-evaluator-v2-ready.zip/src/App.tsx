import { useState, useEffect, useCallback } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────

const VIOLATIONS = [
  { id: "red_light",      label: "Red Light",                  icon: "🔴", severity: "fail",             autoFail: true  },
  { id: "yellow_light",   label: "Yellow Light",               icon: "🟡", severity: "needs-improvement", autoFail: false },
  { id: "block_transit",  label: "Block the Transit",          icon: "🚧", severity: "fail",             autoFail: true  },
  { id: "wrong_exit",     label: "Wrong Exit",                 icon: "↩️", severity: "needs-improvement", autoFail: false },
  { id: "wide_turning",   label: "Wide Turning",               icon: "↗️", severity: "pass",             autoFail: false },
  { id: "tight_turning",  label: "Tight Turning",              icon: "↙️", severity: "pass",             autoFail: false },
  { id: "hit_curve",      label: "Hit the Curve",              icon: "💥", severity: "needs-improvement", autoFail: false },
  { id: "below_15",       label: "Driving Below 15 mph",       icon: "🐢", severity: "pass",             autoFail: false },
  { id: "speed_over",     label: "6–7 Over Speed Limit",       icon: "⚡", severity: "needs-improvement", autoFail: false },
  { id: "stop_sign",      label: "Stop Sign Violation",        icon: "🛑", severity: "fail",             autoFail: true  },
  { id: "prev_accident",  label: "Preventable Accident",       icon: "💢", severity: "fail",             autoFail: true  },
  { id: "danger_lane",    label: "Dangerous Lane Change",      icon: "🚨", severity: "fail",             autoFail: true  },
  { id: "near_miss",      label: "Near Miss Accident",         icon: "⚠️", severity: "fail",             autoFail: true  },
];

const SEVERITY_POINTS = { "pass": 1, "needs-improvement": 3, "fail": 5 };
const SEVERITY_COLOR  = {
  "pass":             { bg: "#2563EB", dim: "#1e3a8a33", border: "#2563EB", text: "#93c5fd" },
  "needs-improvement":{ bg: "#D97706", dim: "#92400e33", border: "#D97706", text: "#fcd34d" },
  "fail":             { bg: "#DC2626", dim: "#7f1d1d33", border: "#DC2626", text: "#fca5a5" },
};

const QUICK_COMMENTS = [
  "Needs more backing practice.",
  "Needs better mirror usage.",
  "Misses traffic signs.",
  "Wrong exit selection.",
  "Needs more trip planning practice.",
  "Good attitude and willingness to learn.",
  "Improves with repetition.",
  "Needs more miles before upgrade.",
];

const STORAGE_KEY = "cdl_evaluations_v2";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function calcScore(counts) {
  return VIOLATIONS.reduce((sum, v) => sum + (counts[v.id] || 0) * SEVERITY_POINTS[v.severity], 0);
}

function hasAutoFail(counts) {
  return VIOLATIONS.some((v) => v.autoFail && (counts[v.id] || 0) > 0);
}

function getRating(score, autoFail) {
  if (autoFail) return "FAIL";
  if (score === 0) return "PASS";
  if (score <= 4)  return "PASS";
  if (score <= 7)  return "NEEDS IMPROVEMENT";
  return "FAIL";
}

function getScoreLevel(score) {
  if (score <= 4) return "pass";
  if (score <= 7) return "needs-improvement";
  return "fail";
}

function loadEvals() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { return []; }
}

function saveEval(ev) {
  const all = loadEvals();
  all.unshift(ev);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function deleteEval(id) {
  const all = loadEvals().filter((e) => e.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function today() {
  return new Date().toISOString().split("T")[0];
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function SectionLabel({ children }) {
  return (
    <div style={{ fontSize: 10, color: "#555", letterSpacing: 3, marginBottom: 10, fontWeight: 700 }}>
      {children}
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder = "" }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontSize: 10, color: "#666", letterSpacing: 2, marginBottom: 4 }}>{label}</div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width: "100%", boxSizing: "border-box",
          background: "#0f0f13", border: "1px solid #2a2a35",
          borderRadius: 8, padding: "10px 12px",
          color: "#e8e8e8", fontSize: 14,
          fontFamily: "'Courier New', monospace",
          outline: "none",
        }}
      />
    </div>
  );
}

function ProgressBar({ score }) {
  const level = getScoreLevel(score);
  const col = SEVERITY_COLOR[level].bg;
  const pct = Math.min(100, (score / 12) * 100);
  return (
    <div style={{ height: 8, background: "#1e1e2a", borderRadius: 4, overflow: "hidden", marginTop: 8 }}>
      <div style={{
        height: "100%", width: `${pct}%`,
        background: col,
        borderRadius: 4,
        transition: "width 0.4s, background 0.4s",
        boxShadow: `0 0 8px ${col}88`,
      }} />
    </div>
  );
}

// ─── Report Generator ─────────────────────────────────────────────────────────

function generateReportHTML(ev) {
  const { info, counts, notes, score, autoFail, rating } = ev;
  const ratingColor = rating === "PASS" ? "#16a34a" : rating === "NEEDS IMPROVEMENT" ? "#D97706" : "#DC2626";
  const violRows = VIOLATIONS
    .filter((v) => (counts[v.id] || 0) > 0)
    .map((v) => `
      <tr>
        <td>${v.icon} ${v.label}</td>
        <td style="text-align:center">${v.severity === "needs-improvement" ? "NEEDS IMPROVEMENT" : v.severity.toUpperCase()}${v.autoFail ? " ⚡AUTO-FAIL" : ""}</td>
        <td style="text-align:center">${SEVERITY_POINTS[v.severity]}</td>
        <td style="text-align:center">${counts[v.id]}</td>
        <td style="text-align:center">${(counts[v.id] || 0) * SEVERITY_POINTS[v.severity]}</td>
      </tr>
    `).join("");

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>CDL Evaluation Report</title>
<style>
  body { font-family: 'Courier New', monospace; background: #fff; color: #111; margin: 0; padding: 32px; }
  h1 { font-size: 22px; border-bottom: 3px solid #111; padding-bottom: 8px; margin-bottom: 4px; }
  .subtitle { color: #555; font-size: 12px; letter-spacing: 2px; margin-bottom: 24px; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 24px; margin-bottom: 24px; }
  .field label { font-size: 10px; color: #888; letter-spacing: 2px; }
  .field p { margin: 2px 0 0; font-size: 14px; font-weight: 700; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 12px; }
  th { background: #111; color: #fff; padding: 8px; text-align: left; }
  td { padding: 7px 8px; border-bottom: 1px solid #ddd; }
  tr:nth-child(even) td { background: #f5f5f5; }
  .rating-box { border: 3px solid ${ratingColor}; border-radius: 8px; padding: 16px 24px; text-align: center; display: inline-block; }
  .rating-label { font-size: 28px; font-weight: 900; color: ${ratingColor}; }
  .score-big { font-size: 40px; font-weight: 900; }
  .notes-box { background: #f5f5f5; border-left: 4px solid #111; padding: 12px 16px; border-radius: 4px; font-size: 13px; white-space: pre-wrap; }
  .autofail-banner { background: #fee2e2; border: 2px solid #DC2626; border-radius: 6px; padding: 10px 16px; color: #DC2626; font-weight: 700; margin-bottom: 16px; font-size: 13px; }
  @media print { body { padding: 0; } }
</style>
</head>
<body>
<h1>🚗 CDL Trainee Evaluation</h1>
<div class="subtitle">PROFESSIONAL DRIVER EVALUATION REPORT</div>
<div class="grid">
  <div class="field"><label>TRAINEE NAME</label><p>${info.traineeName || "—"}</p></div>
  <div class="field"><label>TRAINER NAME</label><p>${info.trainerName || "—"}</p></div>
  <div class="field"><label>DATE</label><p>${info.date || "—"}</p></div>
  <div class="field"><label>LOCATION</label><p>${info.location || "—"}</p></div>
</div>
${autoFail ? `<div class="autofail-banner">⚡ AUTOMATIC FAIL — Critical violation recorded that triggers immediate failure regardless of total score.</div>` : ""}
<h2 style="font-size:14px;letter-spacing:2px;margin-bottom:8px">VIOLATIONS</h2>
${violRows ? `
<table>
  <thead><tr><th>Violation</th><th>Severity</th><th>Pts Each</th><th>Count</th><th>Total Pts</th></tr></thead>
  <tbody>${violRows}</tbody>
</table>` : `<p style="color:#888;font-size:13px">No violations recorded.</p>`}
<div style="display:flex;gap:32px;align-items:center;margin-bottom:24px">
  <div>
    <div style="font-size:10px;color:#888;letter-spacing:2px">TOTAL SCORE</div>
    <div class="score-big">${score}</div>
  </div>
  <div class="rating-box">
    <div style="font-size:10px;color:#888;letter-spacing:2px;margin-bottom:4px">FINAL RESULT</div>
    <div class="rating-label">${rating}</div>
  </div>
</div>
${notes ? `<h2 style="font-size:14px;letter-spacing:2px;margin-bottom:8px">TRAINER NOTES</h2><div class="notes-box">${notes}</div>` : ""}
<div style="margin-top:48px;border-top:1px solid #ccc;padding-top:16px;font-size:10px;color:#aaa;letter-spacing:1px">
  Generated ${new Date().toLocaleString()} · CDL Evaluation System v2
</div>
</body>
</html>`;
}

// ─── Main App ─────────────────────────────────────────────────────────────────

const PAGES = { eval: "eval", history: "history", detail: "detail" };

export default function App() {
  const [page, setPage]         = useState(PAGES.eval);
  const [info, setInfo]         = useState({ traineeName: "", trainerName: "", date: today(), location: "" });
  const [counts, setCounts]     = useState(() => Object.fromEntries(VIOLATIONS.map((v) => [v.id, 0])));
  const [notes, setNotes]       = useState("");
  const [evals, setEvals]       = useState(loadEvals);
  const [detailEv, setDetailEv] = useState(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [saved, setSaved]       = useState(false);

  const score    = calcScore(counts);
  const autoFail = hasAutoFail(counts);
  const rating   = getRating(score, autoFail);
  const level    = getScoreLevel(score);

  const passCount  = VIOLATIONS.filter((v) => v.severity === "pass").reduce((s, v) => s + (counts[v.id] || 0), 0);
  const needsCount = VIOLATIONS.filter((v) => v.severity === "needs-improvement").reduce((s, v) => s + (counts[v.id] || 0), 0);
  const failCount  = VIOLATIONS.filter((v) => v.severity === "fail").reduce((s, v) => s + (counts[v.id] || 0), 0);

  const setInfoField = (k) => (v) => setInfo((p) => ({ ...p, [k]: v }));

  const increment = (id) => { setCounts((p) => ({ ...p, [id]: p[id] + 1 })); setSaved(false); };
  const decrement = (id) => { setCounts((p) => ({ ...p, [id]: Math.max(0, p[id] - 1) })); setSaved(false); };

  const handleSave = () => {
    const ev = {
      id: Date.now().toString(),
      savedAt: new Date().toISOString(),
      info, counts, notes, score, autoFail, rating,
    };
    saveEval(ev);
    setEvals(loadEvals());
    setSaved(true);
  };

  const handleReport = (ev) => {
    const html = generateReportHTML(ev);
    const win = window.open("", "_blank");
    if (win) { win.document.write(html); win.document.close(); win.print(); }
  };

  const handleDelete = (id) => {
    deleteEval(id);
    setEvals(loadEvals());
    if (detailEv?.id === id) { setDetailEv(null); setPage(PAGES.history); }
  };

  const handleReset = () => {
    setCounts(Object.fromEntries(VIOLATIONS.map((v) => [v.id, 0])));
    setNotes("");
    setInfo({ traineeName: "", trainerName: "", date: today(), location: "" });
    setSaved(false);
    setConfirmReset(false);
  };

  const ratingColor = rating === "PASS" ? "#16a34a" : rating === "NEEDS IMPROVEMENT" ? "#D97706" : "#DC2626";

  // ── Shared styles ──────────────────────────────────────────────────────────
  const S = {
    app: {
      minHeight: "100vh",
      background: "#0f0f13",
      fontFamily: "'Courier New', monospace",
      color: "#e8e8e8",
      paddingBottom: 80,
    },
    header: {
      background: "#18181f",
      borderBottom: "2px solid #2a2a35",
      padding: "14px 16px",
      position: "sticky", top: 0, zIndex: 200,
      display: "flex", alignItems: "center", justifyContent: "space-between",
    },
    card: {
      background: "#18181f",
      border: "1px solid #2a2a35",
      borderRadius: 12,
      padding: "16px",
      marginBottom: 12,
    },
    tabBar: {
      position: "fixed", bottom: 0, left: 0, right: 0,
      background: "#18181f",
      borderTop: "2px solid #2a2a35",
      display: "flex",
      zIndex: 200,
    },
    tab: (active) => ({
      flex: 1, padding: "12px 0", textAlign: "center",
      fontSize: 11, letterSpacing: 2, cursor: "pointer",
      color: active ? "#fff" : "#555",
      borderTop: active ? "2px solid #2563EB" : "2px solid transparent",
      background: "none", border: "none", fontFamily: "'Courier New', monospace",
    }),
  };

  // ── Eval Page ──────────────────────────────────────────────────────────────
  const EvalPage = () => (
    <div style={{ maxWidth: 640, margin: "0 auto", padding: "16px 14px 0" }}>

      {/* Score Legend */}
      <div style={{ ...S.card, padding: "12px 14px" }}>
        <SectionLabel>SCORING LEGEND</SectionLabel>
        <div style={{ display: "flex", gap: 8 }}>
          {[["pass","🟦","1-4 pts","PASS"],["needs-improvement","🟨","5-7 pts","NEEDS IMPR."],["fail","🟥","8+ pts","FAIL"]].map(([sev,em,pts,lbl])=>(
            <div key={sev} style={{
              flex:1, background: SEVERITY_COLOR[sev].dim,
              border: `1px solid ${SEVERITY_COLOR[sev].border}`,
              borderRadius: 8, padding: "8px 6px", textAlign: "center",
            }}>
              <div style={{ fontSize: 16 }}>{em}</div>
              <div style={{ fontSize: 9, color: SEVERITY_COLOR[sev].text, letterSpacing:1, marginTop:3 }}>{pts}</div>
              <div style={{ fontSize: 9, color: SEVERITY_COLOR[sev].text, letterSpacing:1, fontWeight:700 }}>{lbl}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Live Dashboard */}
      <div style={{ ...S.card }}>
        <SectionLabel>LIVE DASHBOARD</SectionLabel>
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          {[["pass","PASS",passCount],["needs-improvement","NEEDS IMPR.",needsCount],["fail","FAIL",failCount]].map(([sev,lbl,cnt])=>(
            <div key={sev} style={{
              flex:1, background: SEVERITY_COLOR[sev].dim,
              border:`1px solid ${SEVERITY_COLOR[sev].border}`,
              borderRadius: 8, padding:"10px 4px", textAlign:"center",
            }}>
              <div style={{ fontSize:20, fontWeight:900, color: SEVERITY_COLOR[sev].bg }}>{cnt}</div>
              <div style={{ fontSize:9, color:"#666", letterSpacing:2, marginTop:2 }}>{lbl}</div>
            </div>
          ))}
          <div style={{
            flex:1.4, background:"#0f0f13", border:"1px solid #2a2a35",
            borderRadius:8, padding:"10px 4px", textAlign:"center",
          }}>
            <div style={{ fontSize:20, fontWeight:900, color: SEVERITY_COLOR[level].bg }}>{score}</div>
            <div style={{ fontSize:9, color:"#666", letterSpacing:2, marginTop:2 }}>SCORE</div>
          </div>
        </div>
        <ProgressBar score={score} />
        <div style={{
          marginTop:10, textAlign:"center",
          fontSize:13, fontWeight:800, letterSpacing:2,
          color: ratingColor,
          background: ratingColor + "22",
          border:`1px solid ${ratingColor}`,
          borderRadius:8, padding:"8px 0",
        }}>
          {autoFail ? "⚡ AUTO FAIL — Critical violation" : rating}
        </div>
      </div>

      {/* Trainee Info */}
      <div style={S.card}>
        <SectionLabel>TRAINEE INFORMATION</SectionLabel>
        <Field label="TRAINEE NAME" value={info.traineeName} onChange={setInfoField("traineeName")} placeholder="Full name" />
        <Field label="TRAINER NAME" value={info.trainerName} onChange={setInfoField("trainerName")} placeholder="Trainer" />
        <div style={{ display:"flex", gap:10 }}>
          <div style={{ flex:1 }}><Field label="DATE" value={info.date} onChange={setInfoField("date")} type="date" /></div>
          <div style={{ flex:1 }}><Field label="LOCATION" value={info.location} onChange={setInfoField("location")} placeholder="City / Route" /></div>
        </div>
      </div>

      {/* Violations */}
      <div style={S.card}>
        <SectionLabel>VIOLATIONS</SectionLabel>
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {VIOLATIONS.map((v) => {
            const sc = SEVERITY_COLOR[v.severity];
            const cnt = counts[v.id] || 0;
            const triggered = v.autoFail && cnt > 0;
            return (
              <div key={v.id} style={{
                background: triggered ? "#7f1d1d22" : cnt > 0 ? sc.dim : "#0f0f13",
                border:`1px solid ${triggered ? "#DC2626" : cnt>0 ? sc.border : "#2a2a35"}`,
                borderLeft:`4px solid ${sc.bg}`,
                borderRadius:10, padding:"11px 12px",
                display:"flex", alignItems:"center", gap:10,
                transition:"all 0.15s",
              }}>
                <span style={{ fontSize:18, minWidth:26 }}>{v.icon}</span>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:13, fontWeight:600, color: cnt>0?"#fff":"#ccc", lineHeight:1.2 }}>
                    {v.label}
                    {v.autoFail && <span style={{ fontSize:9, color:"#f87171", letterSpacing:1, marginLeft:6 }}>AUTO-FAIL</span>}
                  </div>
                  <div style={{ fontSize:9, color:sc.bg, letterSpacing:2, marginTop:2 }}>
                    {v.severity === "needs-improvement" ? "NEEDS IMPROVEMENT" : v.severity.toUpperCase()} · {SEVERITY_POINTS[v.severity]} PT{SEVERITY_POINTS[v.severity]>1?"S":""}
                  </div>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                  {cnt > 0 && (
                    <button onClick={() => decrement(v.id)} style={{
                      background:"#2a2a35", border:"none", borderRadius:6,
                      color:"#aaa", width:32, height:32, fontSize:18, cursor:"pointer",
                      fontFamily:"inherit", display:"flex", alignItems:"center", justifyContent:"center",
                    }}>−</button>
                  )}
                  {cnt > 0 && (
                    <div style={{ minWidth:28, textAlign:"center", fontSize:18, fontWeight:900, color:sc.bg }}>{cnt}</div>
                  )}
                  <button onClick={() => increment(v.id)} style={{
                    background: sc.bg, border:"none", borderRadius:10,
                    color:"#fff", width:48, height:48, fontSize:24, cursor:"pointer",
                    fontWeight:900, boxShadow:`0 0 12px ${sc.bg}55`,
                    transition:"transform 0.1s",
                    display:"flex", alignItems:"center", justifyContent:"center",
                    fontFamily:"inherit",
                  }}
                    onPointerDown={(e)=>e.currentTarget.style.transform="scale(0.91)"}
                    onPointerUp={(e)=>e.currentTarget.style.transform="scale(1)"}
                    onPointerLeave={(e)=>e.currentTarget.style.transform="scale(1)"}
                  >+</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Notes */}
      <div style={S.card}>
        <SectionLabel>TRAINER NOTES</SectionLabel>
        <div style={{ display:"flex", flexWrap:"wrap", gap:6, marginBottom:10 }}>
          {QUICK_COMMENTS.map((c) => (
            <button key={c} onClick={() => setNotes((p) => p ? p + " " + c : c)}
              style={{
                background:"#0f0f13", border:"1px solid #2a2a35",
                borderRadius:20, padding:"5px 10px", color:"#aaa",
                fontSize:11, cursor:"pointer", fontFamily:"inherit",
                letterSpacing:0.5,
              }}>
              + {c}
            </button>
          ))}
        </div>
        <textarea value={notes} onChange={(e)=>setNotes(e.target.value)}
          placeholder="Add trainer observations..."
          rows={4}
          style={{
            width:"100%", boxSizing:"border-box",
            background:"#0f0f13", border:"1px solid #2a2a35",
            borderRadius:8, padding:"10px 12px",
            color:"#e8e8e8", fontSize:13,
            fontFamily:"'Courier New', monospace",
            outline:"none", resize:"vertical",
          }}
        />
      </div>

      {/* Actions */}
      <div style={{ display:"flex", gap:10, marginBottom:12 }}>
        <button onClick={handleSave} style={{
          flex:2, background: saved ? "#16a34a" : "#2563EB",
          border:"none", borderRadius:12, color:"#fff",
          padding:"15px 0", fontSize:14, fontWeight:700,
          letterSpacing:2, cursor:"pointer", fontFamily:"inherit",
          transition:"background 0.3s",
        }}>
          {saved ? "✓ SAVED" : "💾 SAVE SESSION"}
        </button>
        <button onClick={() => handleReport({ info, counts, notes, score, autoFail, rating })} style={{
          flex:1.2, background:"#18181f", border:"1px solid #2a2a35",
          borderRadius:12, color:"#aaa",
          padding:"15px 0", fontSize:13, fontWeight:700,
          letterSpacing:1, cursor:"pointer", fontFamily:"inherit",
        }}>
          📄 REPORT
        </button>
      </div>
      <button onClick={() => setConfirmReset(true)} style={{
        width:"100%", background:"transparent", border:"1px solid #3a1a1a",
        borderRadius:12, color:"#7f1d1d", padding:"13px 0",
        fontSize:13, letterSpacing:2, cursor:"pointer", fontFamily:"inherit",
      }}>
        🗑 RESET EVALUATION
      </button>

      {/* Confirm Reset Modal */}
      {confirmReset && (
        <div style={{
          position:"fixed", inset:0, background:"#000000cc",
          display:"flex", alignItems:"center", justifyContent:"center", zIndex:999,
          padding:24,
        }}>
          <div style={{
            background:"#18181f", border:"1px solid #DC2626",
            borderRadius:16, padding:28, maxWidth:320, width:"100%",
          }}>
            <div style={{ fontSize:16, fontWeight:700, marginBottom:8 }}>Reset Evaluation?</div>
            <div style={{ fontSize:13, color:"#888", marginBottom:20 }}>
              All current violation counts, notes, and trainee info will be cleared. This cannot be undone.
            </div>
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={() => setConfirmReset(false)} style={{
                flex:1, background:"#2a2a35", border:"none", borderRadius:10,
                color:"#ccc", padding:"12px 0", fontSize:13, cursor:"pointer", fontFamily:"inherit",
              }}>Cancel</button>
              <button onClick={handleReset} style={{
                flex:1, background:"#DC2626", border:"none", borderRadius:10,
                color:"#fff", padding:"12px 0", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"inherit",
              }}>Reset</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // ── History Page ───────────────────────────────────────────────────────────
  const HistoryPage = () => (
    <div style={{ maxWidth:640, margin:"0 auto", padding:"16px 14px 0" }}>
      <SectionLabel>PREVIOUS EVALUATIONS ({evals.length})</SectionLabel>
      {evals.length === 0 && (
        <div style={{ textAlign:"center", color:"#444", fontSize:13, marginTop:48, letterSpacing:2 }}>
          NO SAVED EVALUATIONS YET
        </div>
      )}
      {evals.map((ev) => {
        const rc = ev.rating === "PASS" ? "#16a34a" : ev.rating === "NEEDS IMPROVEMENT" ? "#D97706" : "#DC2626";
        return (
          <div key={ev.id} style={{
            ...S.card, cursor:"pointer",
            borderLeft:`4px solid ${rc}`,
          }} onClick={() => { setDetailEv(ev); setPage(PAGES.detail); }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
              <div>
                <div style={{ fontSize:15, fontWeight:700, color:"#fff" }}>
                  {ev.info.traineeName || "Unknown Trainee"}
                </div>
                <div style={{ fontSize:11, color:"#666", marginTop:2 }}>
                  {ev.info.date} · {ev.info.location || "No location"}
                </div>
                <div style={{ fontSize:11, color:"#555", marginTop:1 }}>
                  Trainer: {ev.info.trainerName || "—"}
                </div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontSize:22, fontWeight:900, color: SEVERITY_COLOR[getScoreLevel(ev.score)].bg }}>
                  {ev.score}
                </div>
                <div style={{ fontSize:10, color:rc, letterSpacing:1, fontWeight:700 }}>
                  {ev.rating}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  // ── Detail Page ────────────────────────────────────────────────────────────
  const DetailPage = () => {
    if (!detailEv) return null;
    const ev = detailEv;
    const rc = ev.rating === "PASS" ? "#16a34a" : ev.rating === "NEEDS IMPROVEMENT" ? "#D97706" : "#DC2626";
    return (
      <div style={{ maxWidth:640, margin:"0 auto", padding:"16px 14px 0" }}>
        <button onClick={() => setPage(PAGES.history)} style={{
          background:"transparent", border:"none", color:"#2563EB",
          fontSize:13, cursor:"pointer", fontFamily:"inherit", letterSpacing:1,
          marginBottom:12, padding:0,
        }}>← BACK TO HISTORY</button>
        <div style={S.card}>
          <div style={{ fontSize:18, fontWeight:700, marginBottom:4 }}>{ev.info.traineeName || "Unknown"}</div>
          <div style={{ fontSize:11, color:"#666", marginBottom:12 }}>
            {ev.info.date} · {ev.info.location} · Trainer: {ev.info.trainerName}
          </div>
          <div style={{ display:"flex", gap:16, alignItems:"center", marginBottom:12 }}>
            <div>
              <div style={{ fontSize:10, color:"#666", letterSpacing:2 }}>SCORE</div>
              <div style={{ fontSize:32, fontWeight:900, color: SEVERITY_COLOR[getScoreLevel(ev.score)].bg }}>
                {ev.score}
              </div>
            </div>
            <div style={{
              flex:1, background:rc+"22", border:`2px solid ${rc}`,
              borderRadius:10, padding:"10px 0", textAlign:"center",
              fontSize:16, fontWeight:800, color:rc, letterSpacing:2,
            }}>
              {ev.autoFail ? "⚡ AUTO FAIL" : ev.rating}
            </div>
          </div>
          <ProgressBar score={ev.score} />
        </div>
        <div style={S.card}>
          <SectionLabel>VIOLATIONS</SectionLabel>
          {VIOLATIONS.filter((v) => (ev.counts[v.id] || 0) > 0).length === 0
            ? <div style={{ color:"#444", fontSize:12 }}>No violations recorded.</div>
            : VIOLATIONS.filter((v) => (ev.counts[v.id] || 0) > 0).map((v) => (
              <div key={v.id} style={{
                display:"flex", justifyContent:"space-between", alignItems:"center",
                padding:"8px 0", borderBottom:"1px solid #2a2a35",
              }}>
                <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                  <span>{v.icon}</span>
                  <div>
                    <div style={{ fontSize:13 }}>{v.label}</div>
                    <div style={{ fontSize:10, color: SEVERITY_COLOR[v.severity].bg }}>
                      {v.severity === "needs-improvement" ? "NEEDS IMPROVEMENT" : v.severity.toUpperCase()} · {SEVERITY_POINTS[v.severity]} pt ea
                    </div>
                  </div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ fontSize:16, fontWeight:700, color: SEVERITY_COLOR[v.severity].bg }}>
                    ×{ev.counts[v.id]}
                  </div>
                  <div style={{ fontSize:10, color:"#666" }}>
                    {(ev.counts[v.id] || 0) * SEVERITY_POINTS[v.severity]} pts
                  </div>
                </div>
              </div>
            ))
          }
        </div>
        {ev.notes && (
          <div style={S.card}>
            <SectionLabel>TRAINER NOTES</SectionLabel>
            <div style={{ fontSize:13, color:"#ccc", lineHeight:1.6, whiteSpace:"pre-wrap" }}>{ev.notes}</div>
          </div>
        )}
        <div style={{ display:"flex", gap:10, marginBottom:12 }}>
          <button onClick={() => handleReport(ev)} style={{
            flex:1, background:"#2563EB", border:"none", borderRadius:12,
            color:"#fff", padding:"14px 0", fontSize:13, fontWeight:700,
            letterSpacing:2, cursor:"pointer", fontFamily:"inherit",
          }}>📄 GENERATE REPORT</button>
          <button onClick={() => { if(window.confirm("Delete this evaluation?")) handleDelete(ev.id); }} style={{
            background:"transparent", border:"1px solid #3a1a1a",
            borderRadius:12, color:"#7f1d1d", padding:"14px 16px",
            fontSize:13, cursor:"pointer", fontFamily:"inherit",
          }}>🗑</button>
        </div>
      </div>
    );
  };

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div style={S.app}>
      {/* Header */}
      <div style={S.header}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:20 }}>🚗</span>
          <div>
            <div style={{ fontSize:14, fontWeight:700, color:"#fff", letterSpacing:1 }}>CDL EVALUATOR <span style={{ color:"#2563EB" }}>v2</span></div>
            <div style={{ fontSize:9, color:"#555", letterSpacing:2 }}>
              {page === PAGES.eval ? "EVALUATION" : page === PAGES.history ? "HISTORY" : "DETAIL"}
            </div>
          </div>
        </div>
        {page === PAGES.eval && (
          <div style={{
            background: score === 0 && !autoFail ? "#16a34a22" : SEVERITY_COLOR[level].dim,
            border:`1px solid ${score === 0 && !autoFail ? "#16a34a" : SEVERITY_COLOR[level].bg}`,
            borderRadius:8, padding:"5px 12px",
            fontSize:12, color: score === 0 && !autoFail ? "#4ade80" : SEVERITY_COLOR[level].text,
            fontWeight:700, letterSpacing:1,
          }}>
            {autoFail ? "⚡ AUTO FAIL" : score === 0 ? "✓ CLEAN" : `${score} PTS`}
          </div>
        )}
      </div>

      {/* Page Content */}
      {page === PAGES.eval    && <EvalPage />}
      {page === PAGES.history && <HistoryPage />}
      {page === PAGES.detail  && <DetailPage />}

      {/* Tab Bar */}
      <div style={S.tabBar}>
        <button style={S.tab(page === PAGES.eval)} onClick={() => setPage(PAGES.eval)}>
          <div style={{ fontSize:18 }}>📋</div>
          <div>EVALUATE</div>
        </button>
        <button style={S.tab(page === PAGES.history || page === PAGES.detail)} onClick={() => setPage(PAGES.history)}>
          <div style={{ fontSize:18 }}>📁</div>
          <div>HISTORY {evals.length > 0 ? `(${evals.length})` : ""}</div>
        </button>
      </div>
    </div>
  );
}
